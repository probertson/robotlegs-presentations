DELETE FROM main.contacts
WHERE contactId = :contactId